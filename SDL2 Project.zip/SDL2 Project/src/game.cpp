#include <bits/stdc++.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include <time.h>
#include "RenderWindow.h"
#include "LoadMainScreen.h"
#include "run_game.h"
using namespace std;
#define FPS 60
#define WIN_HEIGHT 720
#define WIN_WIDTH 1280

struct high {
	char name[50];
	int score;
} ;

void surface_error(const char* sector) {
	printf("%s surface error: %s\n", sector, SDL_GetError());
	SDL_DestroyRenderer(rendd);
	SDL_DestroyWindow(start_win);
	SDL_Quit();
}

void texture_error(const char* sector) {
	printf("%s Texture error: %s\n", sector, SDL_GetError());
	SDL_DestroyRenderer(rendd);
	SDL_DestroyWindow(start_win);
	SDL_Quit();
}
int level = 1;
int randoms[101];

void get_random() {
	srand(time(0));
	for (int i = 0; i < 100; i++) {
		int freq = 130 - level * 7;
		int start = freq - 50;
		randoms[i] = (rand() % (freq) + start);
	}
}

void concat(int rank, char *prev, char str[], int a) {
	// to concatenate name with score
	strcat(str, " ");
	prev[0] = rank + '0';
	prev[1] = '.';
	prev[2] = ' ';
	int len = 3;
	for (int i = 0; str[i] != '\0'; i++) {
		prev[len++] = str[i];
	}
	int len2 = 0;
	char str2[100];
	while (a > 0) {
		int tmp = a % 10;
		a /= 10;
		str2[len2] = tmp + '0';
		len2++;
	}
	for (int i = len2 - 1; i >= 0; i--) {
		prev[len++] = str2[i];
	}
	prev[len] = '\0';
}
int on_the_bar(int player_x, int player_y, int player_wid, int player_hei, int bar_x, int bar_y, int bar_wid) {
	if ((player_x + player_wid) >= bar_x && player_x <= (bar_x + bar_wid) && player_y + player_hei <= bar_y)return 1;
	else if ((player_x + player_wid) >= bar_x && player_x <= (bar_x + bar_wid) && (player_y + (player_hei / 4)) >= bar_y)return -1;
	else return 0;
}

int run_new_game() {

	TTF_Font *game_font = TTF_OpenFont("res/font.ttf", 100);
	if (game_font == NULL ) {
		printf( "Failed to load lazy font! SDL_ttf Error: %s\n", TTF_GetError() );
		return 1;
	}
	SDL_Color TextColor = { 0, 0, 255, 0};

	Mix_Music * background_music = Mix_LoadMUS("res/codmusic.mp3");
	Mix_Chunk *fire_effect = Mix_LoadWAV("res/fire.wav");

	Mix_HaltMusic();
	Mix_PlayMusic(background_music, -1);
	Mix_VolumeMusic(15);

	bool escp = 0;
	get_random();
	SDL_Surface* surface = IMG_Load("res/forest_bg2.jpg");
	SDL_Surface* surface2 = IMG_Load("res/forest_bg2.jpg");
	if (!surface) {
		surface_error("Forest background");
		return 1;
	}

	if (!surface2) {
		surface_error("Forest background 2");
		return 1;
	}

	SDL_Texture* forest_bg = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_Texture* forest_bg2 = SDL_CreateTextureFromSurface(rendd, surface2);
	SDL_FreeSurface(surface);
	SDL_FreeSurface(surface2);
	if (!forest_bg) {
		texture_error("Forest Background");
		return 1;
	}
	if (!forest_bg2) {
		texture_error("Forest Background 2");
		return 1;
	}

	// life bar
	surface = IMG_Load("res/life3.png");
	if (!surface) {
		surface_error("Life");
		return 1;
	}

	SDL_Texture* life_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!life_tex) {
		texture_error("Life");
		return 1;
	}

	SDL_Rect current_life,  life;
	int life_wid, life_hei;
	SDL_QueryTexture(life_tex, NULL, NULL, &life_wid, &life_hei);
	current_life.h = life_hei / 5, current_life.y = 0, current_life.w = life_wid, current_life.x = 0;
	life.x = 1500, life.y = 20, life.w = 320, life.h = 70;

	// sprite
	surface = IMG_Load("res/sprite.png");
	if (!surface) {
		surface_error("Sprite");
		return 1;
	}

	SDL_Texture* character = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!character) {
		texture_error("Character");
		return 1;
	}

	surface = IMG_Load("res/fire.png");
	if (!surface) {
		surface_error("Fire");
		return 1;
	}

	SDL_Texture* spike = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!spike) {
		texture_error("Spike");
		return 1;
	}
	surface = IMG_Load("res/bar2.png");
	if (!surface) {
		surface_error("Bar");
		return 1;
	}

	SDL_Texture* bar_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!bar_tex) {
		texture_error("Bar");
		return 1;
	}
	// Rock load
	surface = IMG_Load("res/rock3.png");
	if (!surface) {
		surface_error("Rock");
		return 1;
	}

	SDL_Texture* rock_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!rock_tex) {
		texture_error("Rock");
		return 1;
	}

	//ring load
	surface = IMG_Load("res/ring.png");
	if (!surface) {
		surface_error("Ring");
		return 1;
	}

	SDL_Texture* ring_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!ring_tex) {
		texture_error("Ring");
		return 1;
	}
	int wid = 1920, hei = 1080; // screen heigh and width

	// coins
	surface = IMG_Load("res/coin.png");
	if (!surface) {
		surface_error("coin");
		return 1;
	}
	SDL_Texture* coin_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!coin_tex) {
		texture_error("coin");
		return 1;
	}
	SDL_Rect coin_rect;
	coin_rect.w = 120, coin_rect.h = 120, coin_rect.y = 450, coin_rect.x = -10000;

	// health
	surface = IMG_Load("res/health.png");
	if (!surface) {
		surface_error("health");
		return 1;
	}
	SDL_Texture* health_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!health_tex) {
		texture_error("health");
		return 1;
	}
	SDL_Rect health_rect;
	health_rect.w = 120, health_rect.h = 120, health_rect.y = 450, health_rect.x = -10000;

	//super sneakers
	surface = IMG_Load("res/jump.png");
	if (!surface) {
		surface_error("jump");
		return 1;
	}
	SDL_Texture* jumper_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!jumper_tex) {
		texture_error("jump");
		return 1;
	}
	SDL_Rect jumper_rect[2];
	jumper_rect[0].w = 120, jumper_rect[0].h = 120, jumper_rect[0].y = 450, jumper_rect[0].x = -10000;
	jumper_rect[1].w = 60, jumper_rect[1].h = 50, jumper_rect[1].x = wid - 700, jumper_rect[1].y = 40;


	int whole_width, whole_height, frame_time = 0;
	SDL_QueryTexture(character, NULL, NULL, &whole_width, &whole_height);
	SDL_Rect character_rect, bg , bg2;

	// for 1st background
	bg.x = 0, bg.y = 0;
	bg.w = wid, bg.h = hei;

	// for 2nd background
	bg2.w = wid, bg2.h = hei;
	bg2.x =  wid, bg2.y = 0;

	// for character animation and position
	SDL_Rect playerPosition;
	character_rect.w = whole_width / 5;
	character_rect.h = whole_height / 2;
	character_rect.x = character_rect.y = 0;
	playerPosition.x = 20, playerPosition.y = 720;
	playerPosition.w = playerPosition.h = 200;

	//bar and fire initialization
	SDL_Rect bar_rect_array[5], spike_rect_array[5];
	for (int i = 0; i < 5; i++) {
		bar_rect_array[i].w = 300, bar_rect_array[i].h = 20;
		bar_rect_array[i].x = wid, bar_rect_array[i].y = 650;

		spike_rect_array[i].w = 300, spike_rect_array[i].h = 130;
		spike_rect_array[i].x = wid, spike_rect_array[i].y = 800;
	}

	// rock rectangle
	SDL_Rect rock_rect;
	rock_rect.w = 300, rock_rect.h = 200, rock_rect.x = 100000, rock_rect.y = 720;

	// ring rectangle
	SDL_Rect ring_rect;
	ring_rect.w = ring_rect.h = 350;


	//main animation variables
	int curx = 20, cury = 720, cur = 0, cur_bar = 1, base = cury, health = 5;
	bool touch = 0, crossed_bar = 0, go_up  = 0, jumping = 0, play_music = 1, onfire = 0, hitting_bar = 0, col_health = 0, col_jumper = 0;
	SDL_Event key1;
	int now = 0, start = 0, get_rock = 0, rock_position = (rand() % (500) + 201), direction = 0, jump_height = 300;
	int Score = 0, jump = jump_height;
	struct high h[4], temp;

	int speed = 8, jump_left = 5;

	while (!escp) {

		// speed increasing
		for (int i = 1; i <= 10; i++) {
			if (Score > (3500 * i) && level == i) {
				speed++;
				level++;
			}
		}
		//getting random numbers
		if (start > 99) {
			start = 0;
			get_random();
		}
		//handling user input
		while (SDL_PollEvent(&key1)) {
			switch (key1.type) {
			case SDL_QUIT:
				return 1;
				break;
			case SDL_KEYDOWN:
				switch (key1.key.keysym.scancode) {
				case SDL_SCANCODE_ESCAPE:
					escp = 1;
					break;
				case SDL_SCANCODE_M:
					if (!Mix_PlayingMusic()) {
						Mix_PlayMusic(background_music, -1);
						play_music = 1;
					} else if (Mix_PausedMusic()) {
						Mix_ResumeMusic();
						play_music = 1;
					} else {
						Mix_PauseMusic();
						play_music = 0;
					}
					break;
				}
			}
		}
		if (go_up == 0 && jumping == 0) {
			const Uint8 *keystate = SDL_GetKeyboardState(NULL);
			if (keystate[SDL_SCANCODE_UP]) {
				go_up = 1;
				jump = jump_height;
			} else if (keystate[SDL_SCANCODE_SPACE] && jump_left > 0) {
				go_up = 1;
				jump = 2 * jump_height - 80;
				jump_left--;
			}
		}
		// check if player is on the bar
		int current_bar;
		bool on_bar = 0, under_bar = 0;
		for (int i = 0; i < 5; i++) {
			if (on_the_bar(playerPosition.x, playerPosition.y, playerPosition.w, playerPosition.h, bar_rect_array[i].x, bar_rect_array[i].y, bar_rect_array[i].w) == 1) {
				on_bar = 1;
				current_bar = i;
			} else if (on_the_bar(playerPosition.x, playerPosition.y, playerPosition.w, playerPosition.h, bar_rect_array[i].x, bar_rect_array[i].y, bar_rect_array[i].w) == -1) {
				under_bar = 1;
				current_bar = i;
			}
		}
		if (on_bar) {
			Score += 1;
		}
		// player jumping conditions
		if (go_up) {
			if (direction >= 0) {
				if (playerPosition.y >= cury - jump && under_bar == 0) {
					direction = 1; // go up
				} else if (playerPosition.y >= cury - jump && under_bar == 1) {
					// if player is under the bar and on fire
					if (playerPosition.y - 15 >= bar_rect_array[current_bar].y ) {
						direction = 1;
						if (hitting_bar == 0) {
							hitting_bar = 1;
							health--;
							current_life.y += (life_hei) / 5;
							if (health == 0) {
								escp = 1;
								Mix_HaltMusic();
								Mix_HaltChannel(-1);
							}
						}
					} else {
						direction = -1;
						hitting_bar = 0;
						go_up = 0;
					}
				} else if (playerPosition.y < cury - jump) {
					direction = -1; // go down
					go_up = 1;
				}
				jumping = 1;
			} else {
				if (on_bar == 1 && playerPosition.y + playerPosition.h + 15 > bar_rect_array[current_bar].y) {
					// landed on bar
					direction = 0;
					go_up = 0;
					cury = playerPosition.y;
					jumping = 0;
				} else if (on_bar == 0 && playerPosition.y + 15 > base) {
					// landed on base
					direction = 0;
					go_up = 0;
					jumping = 0;
					cury = base;
				} else jumping = 1;
			}
		} else if (on_bar == 0 && go_up == 0) {
			if (playerPosition.y + 15 < base) {
				direction = -1;
				jumping = 1;
			} else {
				direction = 0;
				cury = playerPosition.y;
				jumping = 0;
			}
		}

		playerPosition.y -= direction * 15;

		//character animation and bar spawn
		frame_time++;
		now++;
		get_rock++;
		if (now == randoms[start]) {
			for (int i = 0; i < 5; i++) {
				if (cur_bar == i) {
					bar_rect_array[i].x = wid;
					spike_rect_array[i].x = wid;
					if (start > 0 && start % 4 == 0)coin_rect.x = wid + 80;
					else if (start > 0 && start % 7 == 0)health_rect.x = wid + 80;
					else if (start > 0 && start % 5 == 0)jumper_rect[0].x = wid + 80;
				}
			}
			start++;
			now = 0;
			cur_bar++;
			cur_bar %= 5;
		}
		if (FPS / frame_time == 12) {
			frame_time = 0;
			character_rect.x += (whole_width / 5);
			cur++;

			if (character_rect.x + character_rect.w >= whole_width) {
				character_rect.x = 0;
				character_rect.y +=  whole_height / 2;
			}
			if (character_rect.y + character_rect.h >= whole_height)
				character_rect.y = 0;
		}

		// rock placement
		if (get_rock == rock_position) {
			rock_rect.x = wid + 100;
			get_rock = 0;
			rock_position = (rand() % (500) + 301);

		}

		//collision with rock
		if (playerPosition.x + playerPosition.w >= rock_rect.x + 50 && playerPosition.y + playerPosition.h >= rock_rect.y + 90 && playerPosition.x < (rock_rect.x + rock_rect.w - 50)) {
			escp = 1;
			Mix_HaltMusic();
			Mix_HaltChannel(-1);
		}

		//collision with coin
		if (on_bar && (playerPosition.x + playerPosition.w >= coin_rect.x && playerPosition.y + playerPosition.h >= coin_rect.y)) {
			Score += 2;
			coin_rect.x = -1000;
		}

		//collsion with health
		if (col_health == 0 && on_bar && (playerPosition.x + playerPosition.w >= health_rect.x && playerPosition.y + playerPosition.h >= health_rect.y) && playerPosition.x <= health_rect.x + health_rect.w && playerPosition.y <= health_rect.y + health_rect.h) {
			health_rect.x = -1000;
			Score += 20;
			if (health < 5) {
				current_life.y -= (life_hei) / 5;
				health++;
			}
			col_health = 1;
		} else if (!on_bar)col_health = 0;

		//collision with jumper
		if (col_jumper == 0 && on_bar && (playerPosition.x + playerPosition.w >= jumper_rect[0].x && playerPosition.y + playerPosition.h >= jumper_rect[0].y) && playerPosition.x <= jumper_rect[0].x + jumper_rect[0].w && playerPosition.y <= jumper_rect[0].y + jumper_rect[0].h) {
			jumper_rect[0].x = -1000;
			Score += 10;
			if (jump_left < 5) {
				jump_left++;
			}
			col_jumper = 1;
		} else if (!on_bar)col_jumper = 0;

		// ring position
		ring_rect.x = playerPosition.x - 50, ring_rect.y = playerPosition.y - 50;

		// life checking
		if (under_bar) {
			if (onfire == 0) {
				onfire = 1;
				health--;
				if (health == 0) {
					escp = 1;
					Mix_HaltMusic();
					Mix_HaltChannel(-1);
				}
				current_life.y += (life_hei) / 5;
			}
		} else onfire = 0;

		//Rendering everything
		SDL_RenderClear(rendd);
		SDL_RenderCopy(rendd, forest_bg2, NULL, &bg2);
		SDL_RenderCopy(rendd, forest_bg, NULL, &bg);
		SDL_RenderCopy(rendd, coin_tex, NULL, &coin_rect);
		SDL_RenderCopy(rendd, life_tex, &current_life, &life);
		SDL_RenderCopy(rendd, health_tex, NULL, &health_rect);
		SDL_RenderCopy(rendd, jumper_tex, NULL, &jumper_rect[0]);
		SDL_RenderCopy(rendd, jumper_tex, NULL, &jumper_rect[1]);

		// render bars and fires
		for (int i = 0; i < 5; i++) {
			SDL_RenderCopy(rendd, bar_tex, NULL, &bar_rect_array[i]);
			SDL_RenderCopy(rendd, spike, NULL, &spike_rect_array[i]);
		}
		SDL_RenderCopy(rendd, rock_tex, NULL, &rock_rect);

		if (under_bar) {
			//blink the player if on fire
			if (frame_time % 2)
				SDL_RenderCopy(rendd, character, &character_rect, &playerPosition);

			if (play_music) {
				Mix_PlayChannel(-1, fire_effect, 0); // play sound effect of fire
				Mix_VolumeChunk(fire_effect, 3); // set volume to 3
			}
		} else {
			SDL_RenderCopy(rendd, character, &character_rect, &playerPosition);
			Mix_HaltChannel(-1);
		}

		//score show on screen
		// Score show on screen
		string scor = to_string(Score);
		surface = TTF_RenderText_Blended(game_font, scor.c_str(), TextColor);
		if (!surface) {
			surface_error("Score on screen");
			return 1;
		}
		SDL_Texture *score_show_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!score_show_tex) {
			texture_error("Score show on screen");
			return 1;
		}
		SDL_Rect score_screen;
		score_screen.w = 90; score_screen.h = 70; score_screen.x = 1600; score_screen.y = 150;

		//jump left
		string c = "";
		c += jump_left + '0';
		surface = TTF_RenderText_Blended(game_font, c.c_str(), TextColor);
		if (!surface) {
			surface_error("jump left");
			return 1;
		}
		SDL_Texture *jump_left_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!jump_left_tex) {
			texture_error("jump left");
			return 1;
		}
		SDL_Rect jump_left_rect;
		jump_left_rect.w = 70; jump_left_rect.h = 50; jump_left_rect.x = wid - 600; jump_left_rect.y = 50;

		//SDL_RenderCopy(rendd, ring_tex, NULL, &ring_rect);
		SDL_RenderCopy(rendd, score_show_tex, NULL, &score_screen);
		SDL_RenderCopy(rendd, jump_left_tex, NULL, &jump_left_rect);
		SDL_RenderPresent(rendd);

		//background logics
		bg.x -= speed, bg2.x -= speed, rock_rect.x -= speed, coin_rect.x -= speed, health_rect.x -= speed, jumper_rect[0].x -= speed;
		// bar and fire moving
		for (int i = 0; i < 5; i++) {
			bar_rect_array[i].x -= speed;
			spike_rect_array[i].x -= speed;
		}
		if (bg.x <= -wid ) bg.x = bg2.x + wid;
		if (bg2.x <= -wid ) bg2.x = bg.x + wid;
	}
	SDL_Event ev1;
	bool done = 0;
	SDL_Texture* text_tex;
	string text = "";

	// asking for name
	surface = IMG_Load("res/scoreback.jpg");
	if (!surface) {
		surface_error("Score background");
		return 1;
	}

	SDL_Texture* score_bg_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!score_bg_tex) {
		texture_error("Score Background");
		return 1;
	}

	SDL_Rect score_bg;
	score_bg.w = 700, score_bg.h = 700, score_bg.x = 530, score_bg.y = 150;

	surface = TTF_RenderText_Blended(game_font, "Enter Your Name:", TextColor);
	if (!surface) {
		surface_error("High score name");
		return 1;
	}
	SDL_Texture* enter_name_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!enter_name_tex) {
		texture_error("High Score name");
		return 1;
	}
	SDL_Rect enter_name_rect;
	enter_name_rect.w = 400 , enter_name_rect.h = 100;
	enter_name_rect.x = 700, enter_name_rect.y = 400;

	SDL_RenderClear(rendd);
	SDL_RenderCopy(rendd, tex, NULL, NULL);
	SDL_RenderCopy(rendd, score_bg_tex, NULL, &score_bg);
	SDL_RenderCopy(rendd, enter_name_tex, NULL, &enter_name_rect);
	SDL_RenderPresent(rendd);
	while (!done) {
		SDL_StartTextInput();
		while (SDL_PollEvent(&ev1)) {
			// switch (ev1.type) {
			if (ev1.type == SDL_QUIT) return 1;
			//Special key input
			else if (ev1.type == SDL_KEYDOWN) {
				//Handle backspace
				if (ev1.key.keysym.sym == SDLK_BACKSPACE && (int)text.size() > 0) {
					text.pop_back();
				} else if (ev1.key.keysym.sym == SDLK_RETURN) {
					// read
					struct high h[4], temp;
					FILE *fp = fopen("res/highscore.txt", "r");

					if (fp == NULL) {
						printf("File Cann't read\n");
						return 1;
					} else {
						for (int i = 0; i < 3; i++) {
							fscanf(fp, "%s %d", &h[i].name, &h[i].score);
						}
					}
					strcpy(h[3].name, text.c_str()), h[3].score = Score;
					//sort
					for (int i = 0; i < 4; i++) {
						for (int j = 0; j < 4; j++) {
							if (i != j && h[i].score > h[j].score) {
								temp = h[i];
								h[i] = h[j];
								h[j] = temp;
							}
						}
					}
					fclose(fp);
					FILE *fr = fopen("res/highscore.txt", "w");
					// write
					if (fr == NULL) {
						printf("File Cann't write\n");
						return 1;
					} else {
						for (int i = 0; i < 3; i++)
							fprintf(fr, "%s %d\n", h[i].name, h[i].score);
					}
					fclose(fr);
					return 0;
				}
			}
			//Special text input event
			else if (ev1.type == SDL_TEXTINPUT) {
				text += ev1.text.text;
			}
		}

		if (text != "") {
			surface = TTF_RenderText_Blended(game_font, text.c_str(), TextColor);
			if (!surface) {
				surface_error("High Score");
				return 1;
			}
			text_tex = SDL_CreateTextureFromSurface(rendd, surface);
			SDL_FreeSurface(surface);
			if (!text_tex) {
				texture_error("High Score");
				return 1;
			}
			SDL_Rect text_rect;
			int wid, hei;
			SDL_QueryTexture(text_tex, NULL, NULL, &wid, &hei);
			text_rect.w = (wid + 10) / 2 , text_rect.h = hei / 2 + 20;
			text_rect.x = 750, text_rect.y = 500;

			SDL_RenderClear(rendd);
			SDL_RenderCopy(rendd, tex, NULL, NULL);
			SDL_RenderCopy(rendd, score_bg_tex, NULL, &score_bg);
			SDL_RenderCopy(rendd, enter_name_tex, NULL, &enter_name_rect);
			SDL_RenderCopy(rendd, text_tex, NULL, &text_rect);
			SDL_RenderPresent(rendd);
		}

	}
	SDL_StopTextInput();
	Mix_HaltMusic();
	Mix_HaltChannel(-1);
	return 0;
}
int show_score() {
	bool off = 0;
	TTF_Font *game_font = TTF_OpenFont("res/font.ttf", 100);
	if (game_font == NULL ) {
		printf( "Failed to load lazy font! SDL_ttf Error: %s\n", TTF_GetError() );
		return 1;
	}
	SDL_Color TextColor = { 0, 0, 255, 0};

	// loading images
	surface = IMG_Load("res/scoreback.jpg");
	if (!surface) {
		surface_error("HighScore background");
		return 1;
	}

	SDL_Texture* highscore_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!highscore_tex) {
		texture_error("Score Background");
		return 1;
	}

	SDL_Rect highscore;
	highscore.w = 700, highscore.h = 700, highscore.x = 530, highscore.y = 150;

	surface = TTF_RenderText_Blended(game_font, "HighScores:", TextColor);
	if (!surface) {
		surface_error("High scores");
		return 1;
	}
	SDL_Texture* highscore_text_tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!highscore_text_tex) {
		texture_error("High Scores");
		return 1;
	}
	SDL_Rect highscore_text_rect;
	highscore_text_rect.w = 400 , highscore_text_rect.h = 100;
	highscore_text_rect.x = 700, highscore_text_rect.y = 200;

	struct high h[4], temp;
	FILE *fp = fopen("res/highscore.txt", "r");
	SDL_Texture* names_tex[3] ;

	SDL_Rect names[3];
	if (fp == NULL) {
		printf("File Cann't read\n");
		return 1;
	} else {
		for (int i = 0; i < 3; i++) {
			fscanf(fp, "%s %d", &h[i].name, &h[i].score);
			char namee[100];
			concat(i + 1, namee, h[i].name, h[i].score);
			surface = TTF_RenderText_Blended(game_font, namee, TextColor);
			if (!surface) {
				surface_error("High score names");
				return 1;
			}
			names_tex[i] = SDL_CreateTextureFromSurface(rendd, surface);
			if (!names_tex[i]) {
				texture_error("High Scores names");
				return 1;
			}
			SDL_FreeSurface(surface);
			names[i].x = 750, names[i].y = 400 + (i * 90), names[i].w = 200, names[i].h = 60;
		}
	}
	SDL_Event escap;

	while (!off) {
		SDL_RenderClear(rendd);
		SDL_RenderCopy(rendd, tex, NULL, NULL);
		SDL_RenderCopy(rendd, highscore_tex, NULL, &highscore);
		SDL_RenderCopy(rendd, highscore_text_tex, NULL, &highscore_text_rect);
		for (int i = 0; i < 3; i++) {
			SDL_RenderCopy(rendd, names_tex[i], NULL, &names[i]);
		}
		SDL_RenderPresent(rendd);
		while (SDL_PollEvent(&escap)) {
			if (escap.type == SDL_KEYDOWN && escap.key.keysym.sym == SDLK_ESCAPE) {
				off = 1;
				break;
			}
		}
	}
	fclose(fp);
	return 0;
}