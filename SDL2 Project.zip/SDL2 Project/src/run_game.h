#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL_mixer.h>

extern int randoms[101];
// bool play_music = 1;
// extern Uint8 *keystate;


void get_random();
int on_the_bar(int player_x, int player_y, int player_wid, int player_hei, int bar_x, int bar_y, int bar_wid);
int run_new_game();
int show_score();