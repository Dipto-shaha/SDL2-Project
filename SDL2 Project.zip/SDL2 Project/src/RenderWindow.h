#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>

extern SDL_Window* start_win;
extern SDL_Renderer* rendd;
extern SDL_Surface* surface;
extern SDL_Texture* tex;

void RenderWindow(const char* p_title, int p_w, int p_h);

// void surface_to_texture(const char* title)


