#pragma once

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>

extern SDL_Rect new_game;
extern SDL_Rect options;
extern SDL_Rect controls;
extern SDL_Rect quitt;
extern SDL_Rect cursor;
extern SDL_Rect score;
extern SDL_Texture* new_game_tex;
extern SDL_Texture* options_tex;
extern SDL_Texture* controls_tex;
extern SDL_Texture* quit_tex;
extern SDL_Texture* cursor_tex;
extern SDL_Texture* score_tex;

int load_screen(int serial);