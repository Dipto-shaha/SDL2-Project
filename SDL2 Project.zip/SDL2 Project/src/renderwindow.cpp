#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>
#include <SDL2/SDL_ttf.h>

#include "LoadMainScreen.h"
#include "RenderWindow.h"

SDL_Window* start_win;
SDL_Renderer* rendd;
SDL_Surface* surface;
SDL_Texture* tex;

void RenderWindow(const char* p_title, int p_w, int p_h) {
	start_win = SDL_CreateWindow(p_title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 1080, SDL_WINDOW_RESIZABLE);
	if (!start_win) {
		printf("Start Window: %s\n", SDL_GetError());
		SDL_Quit();
		return;
	}

	Uint32 render_flags = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC;
	rendd = SDL_CreateRenderer(start_win, -1, render_flags);

	if (!rendd) {
		printf("Renderer: %s\n", SDL_GetError());
		SDL_DestroyWindow(start_win);
		SDL_Quit();
		return;
	}

	surface = IMG_Load("res/dbzbg.png");
	if (!surface) {
		printf("Start Window Surface Error: %s\n", IMG_GetError());
		SDL_DestroyRenderer(rendd);
		SDL_DestroyWindow(start_win);
		SDL_Quit();
		return;
	}

	tex = SDL_CreateTextureFromSurface(rendd, surface);
	SDL_FreeSurface(surface);
	if (!tex) {
		printf("Start Window Texture %s\n", SDL_GetError());
		SDL_DestroyRenderer(rendd);
		SDL_DestroyWindow(start_win);
		SDL_Quit();
		return;
	}
}

