#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>
#include <SDL2/SDL_ttf.h>

#include "LoadMainScreen.h"
#include "RenderWindow.h"

SDL_Rect new_game;
SDL_Rect options;
SDL_Rect controls;
SDL_Rect quitt;
SDL_Rect cursor;
SDL_Rect score;
SDL_Texture* new_game_tex;
SDL_Texture* options_tex;
SDL_Texture* controls_tex;
SDL_Texture* quit_tex;
SDL_Texture* cursor_tex;
SDL_Texture* score_tex;

void SurfaceError(const char* sector) {
	printf("%s surface error: %s\n", sector, SDL_GetError());
	SDL_DestroyRenderer(rendd);
	SDL_DestroyWindow(start_win);
	SDL_Quit();
}

void TextureError(const char* sector) {
	printf("%s Texture error: %s\n", sector, SDL_GetError());
	SDL_DestroyRenderer(rendd);
	SDL_DestroyWindow(start_win);
	SDL_Quit();
}

int load_screen(int serial) {
	//TTF initialization
	TTF_Font *game_font = TTF_OpenFont("res/font.ttf", 100);
	TTF_Font *game_font2 = TTF_OpenFont("res/symbol.ttf", 100);
	if (game_font == NULL || game_font2 == NULL) {
		printf( "Failed to load lazy font! SDL_ttf Error: %s\n", TTF_GetError() );
		return 1;
	}

	SDL_Color TextColor = {255, 250, 0, 0};
	SDL_Color SymbolColor = { 255, 255, 255, 255};

	if (serial == 1) {
		// new game
		surface = TTF_RenderText_Blended(game_font, "New Game", TextColor);
		if (!surface) {
			SurfaceError("New Game");
			return 1;
		}
		new_game_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!new_game_tex) {
			TextureError("New Game");
			return 1;
		}
		// new game rectangle
		new_game.x = 450, new_game.y = 100, new_game.w = 300, new_game.h = 60;

		// loading sound
		surface = TTF_RenderText_Blended(game_font, "Sound", TextColor);
		if (!surface) {
			SurfaceError("Sound");
			return 1;
		}
		options_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!new_game_tex) {
			TextureError("Sound");
			return 1;
		}
		// options rectangle
		options.w = 150, options.h = 60, options.x = 450, options.y = 200;

		// showing controls

		surface = TTF_RenderText_Blended(game_font, "Instructions", TextColor);
		if (!surface) {
			SurfaceError("Instructions");
			return 1;
		}
		controls_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!controls_tex) {
			TextureError("Instructions");
			return 1;
		}
		controls.w = 300; controls.h = 60; controls.x = 450; controls.y = 300;
		// showing quit

		surface = TTF_RenderText_Blended(game_font, "Quit", TextColor);
		if (!surface) {
			SurfaceError("Quit");
			return 1;
		}
		quit_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!quit_tex) {
			TextureError("Quit");
			return 1;
		}
		quitt.w = 150; quitt.h = 60; quitt.x = 450; quitt.y = 500;

		// Cursor
		surface = TTF_RenderText_Blended(game_font2, ">>", SymbolColor);
		if (!surface) {
			SurfaceError("Cursor");
			return 1;
		}
		cursor_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!cursor_tex) {
			TextureError("Cursor");
			return 1;
		}
		cursor.x = 350, cursor.y = 100, cursor.w = 80, cursor.h = 80;

		//score
		surface = TTF_RenderText_Blended(game_font2, "High Score", TextColor);
		if (!surface) {
			SurfaceError("Score");
			return 1;
		}
		score_tex = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!cursor_tex) {
			TextureError("Score");
			return 1;
		}
		score.x = 450, score.y = 400, score.w = 300, score.h = 60;
	}

// shows when selected control
	if (serial == 5) {
		SDL_Surface* surface = IMG_Load("res/instructions.png");
		if (!surface) {
			printf("Controls Surface Error: %s\n", IMG_GetError());
			SDL_DestroyRenderer(rendd);
			SDL_DestroyWindow(start_win);
			SDL_Quit();
			return 1;
		}

		SDL_Texture* control_opt = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!control_opt) {
			printf("Control options Texture %s\n", SDL_GetError());
			SDL_DestroyRenderer(rendd);
			SDL_DestroyWindow(start_win);
			SDL_Quit();
			return 1;
		}

		SDL_Rect control_rect;
		control_rect.w = 800;
		control_rect.h = 400;
		control_rect.x = 500;
		control_rect.y = 300;

		bool escp = 0;
		SDL_Event key1;
		while (!escp) {
			SDL_RenderClear(rendd);
			SDL_RenderCopy(rendd, control_opt, NULL, &control_rect);
			SDL_RenderPresent(rendd);

			while (SDL_PollEvent(&key1)) {
				switch (key1.type) {
				case SDL_QUIT:
					return 1;
					break;
				case SDL_KEYDOWN:
					switch (key1.key.keysym.scancode) {
					case SDL_SCANCODE_ESCAPE:
						escp = 1;
						break;
					}
				}
			}
		}
	}

	if (serial == 6) {
		SDL_Surface* surface = IMG_Load("res/sound.png");
		if (!surface) {
			printf("Sound Surface Error: %s\n", IMG_GetError());
			SDL_DestroyRenderer(rendd);
			SDL_DestroyWindow(start_win);
			SDL_Quit();
			return 1;
		}

		SDL_Texture* sound = SDL_CreateTextureFromSurface(rendd, surface);
		SDL_FreeSurface(surface);
		if (!sound) {
			printf("Sound Texture %s\n", SDL_GetError());
			SDL_DestroyRenderer(rendd);
			SDL_DestroyWindow(start_win);
			SDL_Quit();
			return 1;
		}

		SDL_Rect sound_on_rect;
		sound_on_rect.w = 300;
		sound_on_rect.h = 100;
		sound_on_rect.x = 500;
		sound_on_rect.y = 300;

		bool escp = 0;
		SDL_Event key1;
		while (!escp) {
			SDL_RenderClear(rendd);
			SDL_RenderCopy(rendd, sound, NULL, &sound_on_rect);
			SDL_RenderPresent(rendd);

			while (SDL_PollEvent(&key1)) {
				switch (key1.type) {
				case SDL_QUIT:
					return 1;
					break;
				case SDL_KEYDOWN:
					switch (key1.key.keysym.scancode) {
					case SDL_SCANCODE_ESCAPE:
						escp = 1;
						break;
					}
				}
			}
		}
	}
	return 0;
}