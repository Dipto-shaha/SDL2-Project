#include<bits/stdc++.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_timer.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include "RenderWindow.h"
#include "LoadMainScreen.h"
#include "run_game.h"
#define WIN_HEIGHT 1080
#define WIN_WIDTH 1920

using namespace std;


bool play = 1, close = 0;  // play for sound and close for checking close option

int main(int agr, char* args[]) {
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_AUDIO) != 0)
		printf("video, sound and timer: %s\n", SDL_GetError());
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
		printf("Sound error: %s\n", Mix_GetError());
	Mix_Music *intro_music = Mix_LoadMUS("res/intro.mp3"); // intro music
	RenderWindow ("Flag Warrior", WIN_HEIGHT, WIN_WIDTH);  // Render main window
	if (TTF_Init() == -1) {
		printf("TTF_Init: %s\n", TTF_GetError());
		return 1;
	}
	load_screen(1);  // New Game Screen
	// main game loop
	SDL_Event event1;

	while (!close) {

		if (!Mix_PlayingMusic() && play) Mix_PlayMusic(intro_music, -1);
		Mix_VolumeMusic(15);

		while (SDL_PollEvent(&event1)) {
			switch (event1.type) {
			case SDL_QUIT:
				return 1;
				break;
			case SDL_KEYDOWN:
				switch (event1.key.keysym.scancode) {
				case SDL_SCANCODE_M:
					if (!Mix_PlayingMusic()) {
						Mix_PlayMusic(intro_music, -1);
						play = 1;
					} else if (Mix_PausedMusic()) {
						Mix_ResumeMusic();
						play = 1;
					} else {
						Mix_PauseMusic();
						play = 0;
					}
					break;
				case SDL_SCANCODE_UP:
					if (cursor.y == 100)cursor.y = 500;
					else cursor.y -= 100;
					break;
				case SDL_SCANCODE_DOWN:
					if (cursor.y == 500)cursor.y = 100;
					else cursor.y += 100;
					break;
				}
			}
		}
		int mousex, mousey, buttons = SDL_GetMouseState(&mousex, &mousey);
		if (buttons & SDL_BUTTON(SDL_BUTTON_LEFT)) {
			if (mousex >= quitt.x && mousex <= (quitt.x + quitt.w) && mousey >= quitt.y && mousey <= (quitt.y + quitt.h))
				close = 1;
		}

		// Render everything
		SDL_RenderClear(rendd);
		SDL_RenderCopy(rendd, tex, NULL, NULL);
		SDL_RenderCopy(rendd, cursor_tex, NULL, &cursor);
		// SDL_RenderCopy(rendd, text_tex, NULL, &text_rect);
		SDL_RenderCopy(rendd, new_game_tex, NULL, &new_game);
		SDL_RenderCopy(rendd, options_tex, NULL, &options);
		SDL_RenderCopy(rendd, controls_tex, NULL, &controls);
		SDL_RenderCopy(rendd, quit_tex, NULL, &quitt);
		SDL_RenderCopy(rendd, score_tex, NULL, &score);
		SDL_RenderPresent(rendd);

		buttons = SDL_GetMouseState(&mousex, &mousey);

		if (buttons & SDL_BUTTON(SDL_BUTTON_LEFT)) {
			if (mousex >= new_game.x && mousex <= (new_game.x + new_game.w) && mousey >= new_game.y && mousey <= (new_game.y + new_game.h)) {
				close = run_new_game();
			} else if (mousex >= controls.x && mousex <= (controls.x + controls.w) && mousey >= controls.y && mousey <= (controls.y + controls.h)) {
				close = load_screen(5);
			} else if (mousex >= options.x && mousex <= (options.x + options.w) && mousey >= options.y && mousey <= (options.y + options.h)) {
				close = load_screen(6);
			} else if (mousex >= score.x && mousex <= (score.x + score.w) && mousey >= score.y && mousey <= (score.y + score.h)) {
				close = show_score();
			}
		}
	}

	SDL_StopTextInput();

	SDL_DestroyRenderer(rendd);
	SDL_DestroyWindow(start_win);
	Mix_FreeMusic(intro_music);
	Mix_Quit();
	SDL_Quit();
	return 0;
}